﻿Public Class Form1

    Private Class Nodo
        Public siguiente As Nodo
        Public dato As String

        Sub New(ByVal dato As String)
            Me.dato = dato
        End Sub
    End Class

    Private primero As Nodo, ultimo As Nodo, aux As Nodo
    Private cont As Integer = 0

    Public Sub encolar(dato As String)
        Dim NuevoNodo As New Nodo(dato)

        If primero Is Nothing Then
            primero = NuevoNodo
            ultimo = NuevoNodo
            cont += 1

        Else
            ultimo.siguiente = NuevoNodo
            ultimo = NuevoNodo
        End If
    End Sub

    Private Sub btn_ingresar_Click(sender As Object, e As EventArgs) Handles btn_ingresar.Click
        encolar(tbox1.Text)
        Validar()
    End Sub

    Public Sub apilar(dato As String)
        Dim NuevoNodo As New Nodo(dato)

        ultimo.siguiente = NuevoNodo

    End Sub

    Public Sub Validar()
        aux = primero
        Dim parent_abre As Integer, parent_cierre As Integer
        Dim corche_abre As Integer, corche_cierre As Integer
        Dim llave_abre As Integer, llave_cierre As Integer

        For i As Integer = 1 To aux.dato.Length
            If Mid(aux.dato, i, 1) = "(" Then
                parent_abre += 1

            ElseIf Mid(aux.dato, i, 1) = ")" Then
                parent_cierre += 1

            ElseIf Mid(aux.dato, i, 1) = "[" Then
                corche_abre += 1

            ElseIf Mid(aux.dato, i, 1) = "]" Then
                corche_cierre += 1

            ElseIf Mid(aux.dato, i, 1) = "{" Then
                llave_abre += 1

            ElseIf Mid(aux.dato, i, 1) = "}" Then
                llave_cierre += 1
            End If

            'aux = aux.siguiente
        Next

        If parent_abre <> parent_cierre Then
            MsgBox("Expresion no esta balanceada")

        Else
            MsgBox("Expresion balanceada")
        End If
    End Sub
End Class
