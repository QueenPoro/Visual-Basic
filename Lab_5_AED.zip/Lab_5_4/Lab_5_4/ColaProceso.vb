﻿Public Class ColaProceso

    Private array(1) As Integer, contador As Integer
    Private Class NodoProceso
        Public dato As Integer 'Se crea "puntero" a entero
        Public pSiguiente As NodoProceso 'Se crea "puntero" a siguiente

        'Se crea un constructor
        Public Sub New(dato As Integer)
            Me.dato = dato

        End Sub
    End Class

    'Se crea el "puntero" que apuntara al primero y el que apuntara al ultimo
    Private primero As NodoProceso, ultimo As NodoProceso
    Private aux As NodoProceso

    Public Sub encolar(elemento As Integer)
        'Se crea una instancia de la clase Nodo
        Dim NuevoNodo = New NodoProceso(elemento)
        'Se pregunta si el primero apunta a algo (porque si no se trata de una
        'lista vacia)
        If primero Is Nothing Then
            'Si se trataba de una lista vacia, entonces ahora el nuevo dato
            'Pasa a ser el primero
            primero = NuevoNodo
        Else
            'Como ya habian elementos en la lista entonces el nuevo dato 
            'Se agrega despues del ultimo (imaginar graficamente que la cola 
            'se llena de derecha/ultimo a izquierda/primero)
            ultimo.pSiguiente = NuevoNodo
        End If
        'Para ambos casos del if, el ultimo siempre tiene que apuntar al nuevo nodo
        ultimo = NuevoNodo
    End Sub

    Public Function obtener()
        'Si el ultimo no apunta a nada (lista vacia), se retorna null
        If primero Is Nothing Then
            Return Nothing
        Else
            'Como se trata de una cola (FIRST-IN, FIRST-OUT) el primero
            'en entrar siempre va a ser el primero en salir
            Return primero.dato
        End If
    End Function

    Public Sub eliminar()
        'Al ser una cola se elimina siempre el primer dato que se ingreso

        'Se verifica que la lista no este vacia 
        If primero IsNot Nothing Then
            'Simplemente se hace que el puntero primero, apunte al nodo
            'que se encuentra despues del que esta actualmente como primero
            'el nodo que saldria se tendria que hacer null, pero como es visual
            'esto se hace de forma automatica
            primero = primero.pSiguiente

            If primero Is Nothing Then
                ultimo = Nothing
            End If
        End If
    End Sub

    Public Sub Actualizar()
        aux = primero
        'If ((aux.pSiguiente Is Nothing) And (primero IsNot Nothing)) Then
        'array(0) = primero.dato
        'contador += 1
        'Else
        While (aux.pSiguiente IsNot Nothing)
            ReDim Preserve array(contador)
                array(contador) = aux.pSiguiente.dato
                aux = aux.pSiguiente
                contador += 1
            End While

        'End If
    End Sub

    Public ReadOnly Property obArray(ByVal i As Integer)
        Get
            Return array(i)
        End Get
    End Property

    Public ReadOnly Property obContador()
        Get
            Return contador
        End Get
    End Property

End Class
