﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gb_operaciones = New System.Windows.Forms.GroupBox()
        Me.resultado = New System.Windows.Forms.TextBox()
        Me.label_titulo = New System.Windows.Forms.Label()
        Me.cbox2 = New System.Windows.Forms.ComboBox()
        Me.cbox1 = New System.Windows.Forms.ComboBox()
        Me.tbox_ingresar = New System.Windows.Forms.TextBox()
        Me.btn_agregar = New System.Windows.Forms.Button()
        Me.lb_datos = New System.Windows.Forms.ListBox()
        Me.gb_agregar = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbox_eliminar = New System.Windows.Forms.TextBox()
        Me.btn_eliminar = New System.Windows.Forms.Button()
        Me.gb_eliminar = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rb_cola = New System.Windows.Forms.RadioButton()
        Me.rb_pila = New System.Windows.Forms.RadioButton()
        Me.gb_operaciones.SuspendLayout()
        Me.gb_agregar.SuspendLayout()
        Me.gb_eliminar.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'gb_operaciones
        '
        Me.gb_operaciones.Controls.Add(Me.resultado)
        Me.gb_operaciones.Controls.Add(Me.label_titulo)
        Me.gb_operaciones.Controls.Add(Me.cbox2)
        Me.gb_operaciones.Controls.Add(Me.cbox1)
        Me.gb_operaciones.Enabled = False
        Me.gb_operaciones.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_operaciones.Location = New System.Drawing.Point(314, 93)
        Me.gb_operaciones.Name = "gb_operaciones"
        Me.gb_operaciones.Size = New System.Drawing.Size(404, 185)
        Me.gb_operaciones.TabIndex = 1
        Me.gb_operaciones.TabStop = False
        Me.gb_operaciones.Text = "OPERACIONES"
        '
        'resultado
        '
        Me.resultado.Enabled = False
        Me.resultado.Location = New System.Drawing.Point(188, 84)
        Me.resultado.Name = "resultado"
        Me.resultado.Size = New System.Drawing.Size(189, 26)
        Me.resultado.TabIndex = 3
        Me.resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.resultado.Visible = False
        '
        'label_titulo
        '
        Me.label_titulo.AutoSize = True
        Me.label_titulo.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_titulo.Location = New System.Drawing.Point(22, 89)
        Me.label_titulo.Name = "label_titulo"
        Me.label_titulo.Size = New System.Drawing.Size(160, 16)
        Me.label_titulo.TabIndex = 2
        Me.label_titulo.Text = "Promedio de Elementos"
        Me.label_titulo.Visible = False
        '
        'cbox2
        '
        Me.cbox2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbox2.FormattingEnabled = True
        Me.cbox2.Items.AddRange(New Object() {"Mayor a menor", "Menor a mayor"})
        Me.cbox2.Location = New System.Drawing.Point(219, 43)
        Me.cbox2.Name = "cbox2"
        Me.cbox2.Size = New System.Drawing.Size(158, 24)
        Me.cbox2.TabIndex = 1
        Me.cbox2.Visible = False
        '
        'cbox1
        '
        Me.cbox1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbox1.FormattingEnabled = True
        Me.cbox1.Items.AddRange(New Object() {"Maximo Elemento", "Promedio de Elementos", "Ordenar Elementos"})
        Me.cbox1.Location = New System.Drawing.Point(25, 43)
        Me.cbox1.Name = "cbox1"
        Me.cbox1.Size = New System.Drawing.Size(188, 24)
        Me.cbox1.TabIndex = 0
        '
        'tbox_ingresar
        '
        Me.tbox_ingresar.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbox_ingresar.Location = New System.Drawing.Point(15, 42)
        Me.tbox_ingresar.Name = "tbox_ingresar"
        Me.tbox_ingresar.Size = New System.Drawing.Size(154, 22)
        Me.tbox_ingresar.TabIndex = 0
        Me.tbox_ingresar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_agregar
        '
        Me.btn_agregar.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_agregar.Location = New System.Drawing.Point(176, 38)
        Me.btn_agregar.Name = "btn_agregar"
        Me.btn_agregar.Size = New System.Drawing.Size(75, 30)
        Me.btn_agregar.TabIndex = 1
        Me.btn_agregar.Text = "Agregar"
        Me.btn_agregar.UseVisualStyleBackColor = True
        '
        'lb_datos
        '
        Me.lb_datos.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_datos.FormattingEnabled = True
        Me.lb_datos.ItemHeight = 16
        Me.lb_datos.Location = New System.Drawing.Point(15, 94)
        Me.lb_datos.Name = "lb_datos"
        Me.lb_datos.Size = New System.Drawing.Size(236, 276)
        Me.lb_datos.TabIndex = 2
        '
        'gb_agregar
        '
        Me.gb_agregar.Controls.Add(Me.lb_datos)
        Me.gb_agregar.Controls.Add(Me.btn_agregar)
        Me.gb_agregar.Controls.Add(Me.tbox_ingresar)
        Me.gb_agregar.Enabled = False
        Me.gb_agregar.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_agregar.Location = New System.Drawing.Point(30, 93)
        Me.gb_agregar.Name = "gb_agregar"
        Me.gb_agregar.Size = New System.Drawing.Size(266, 389)
        Me.gb_agregar.TabIndex = 0
        Me.gb_agregar.TabStop = False
        Me.gb_agregar.Text = "AGREGAR"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(22, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(193, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Ingresar elemento a eliminar"
        '
        'tbox_eliminar
        '
        Me.tbox_eliminar.Location = New System.Drawing.Point(221, 35)
        Me.tbox_eliminar.Name = "tbox_eliminar"
        Me.tbox_eliminar.Size = New System.Drawing.Size(127, 26)
        Me.tbox_eliminar.TabIndex = 3
        Me.tbox_eliminar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_eliminar
        '
        Me.btn_eliminar.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_eliminar.Location = New System.Drawing.Point(221, 67)
        Me.btn_eliminar.Name = "btn_eliminar"
        Me.btn_eliminar.Size = New System.Drawing.Size(75, 23)
        Me.btn_eliminar.TabIndex = 4
        Me.btn_eliminar.Text = "Eliminar"
        Me.btn_eliminar.UseVisualStyleBackColor = True
        '
        'gb_eliminar
        '
        Me.gb_eliminar.Controls.Add(Me.btn_eliminar)
        Me.gb_eliminar.Controls.Add(Me.tbox_eliminar)
        Me.gb_eliminar.Controls.Add(Me.Label1)
        Me.gb_eliminar.Enabled = False
        Me.gb_eliminar.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_eliminar.Location = New System.Drawing.Point(314, 298)
        Me.gb_eliminar.Name = "gb_eliminar"
        Me.gb_eliminar.Size = New System.Drawing.Size(404, 184)
        Me.gb_eliminar.TabIndex = 4
        Me.gb_eliminar.TabStop = False
        Me.gb_eliminar.Text = "ELIMINACION"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rb_pila)
        Me.GroupBox3.Controls.Add(Me.rb_cola)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(30, 14)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(404, 63)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "SELECCIONAR ESTRUCTURA"
        '
        'rb_cola
        '
        Me.rb_cola.AutoSize = True
        Me.rb_cola.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb_cola.Location = New System.Drawing.Point(47, 29)
        Me.rb_cola.Name = "rb_cola"
        Me.rb_cola.Size = New System.Drawing.Size(55, 20)
        Me.rb_cola.TabIndex = 0
        Me.rb_cola.TabStop = True
        Me.rb_cola.Text = "Cola"
        Me.rb_cola.UseVisualStyleBackColor = True
        '
        'rb_pila
        '
        Me.rb_pila.AutoSize = True
        Me.rb_pila.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rb_pila.Location = New System.Drawing.Point(135, 29)
        Me.rb_pila.Name = "rb_pila"
        Me.rb_pila.Size = New System.Drawing.Size(51, 20)
        Me.rb_pila.TabIndex = 1
        Me.rb_pila.TabStop = True
        Me.rb_pila.Text = "Pila"
        Me.rb_pila.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(754, 511)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.gb_eliminar)
        Me.Controls.Add(Me.gb_operaciones)
        Me.Controls.Add(Me.gb_agregar)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.gb_operaciones.ResumeLayout(False)
        Me.gb_operaciones.PerformLayout()
        Me.gb_agregar.ResumeLayout(False)
        Me.gb_agregar.PerformLayout()
        Me.gb_eliminar.ResumeLayout(False)
        Me.gb_eliminar.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gb_operaciones As GroupBox
    Friend WithEvents cbox1 As ComboBox
    Friend WithEvents cbox2 As ComboBox
    Friend WithEvents label_titulo As Label
    Friend WithEvents resultado As TextBox
    Friend WithEvents tbox_ingresar As TextBox
    Friend WithEvents btn_agregar As Button
    Friend WithEvents lb_datos As ListBox
    Friend WithEvents gb_agregar As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents tbox_eliminar As TextBox
    Friend WithEvents btn_eliminar As Button
    Friend WithEvents gb_eliminar As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents rb_pila As RadioButton
    Friend WithEvents rb_cola As RadioButton
End Class
