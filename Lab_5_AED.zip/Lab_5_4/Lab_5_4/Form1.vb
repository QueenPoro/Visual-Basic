﻿Public Class Form1

    Dim cont As Integer, cont2 As Integer

    Private Class NodoProceso
        Public dato As Integer 'Se crea "puntero" a entero
        Public pSiguiente As NodoProceso 'Se crea "puntero" a siguiente

        'Se crea un constructor
        Public Sub New(dato As Integer)
            Me.dato = dato
        End Sub
    End Class

    'Se crea el "puntero" que apuntara al primero y el que apuntara al ultimo
    Private primero As NodoProceso, ultimo As NodoProceso
    Private aux As NodoProceso

    Public Sub encolar(elemento As Integer)
        'Se crea una instancia de la clase Nodo
        Dim NuevoNodo = New NodoProceso(elemento)
        'Se pregunta si el primero apunta a algo (porque si no se trata de una
        'lista vacia)
        If primero Is Nothing Then
            'Si se trataba de una lista vacia, entonces ahora el nuevo dato
            'Pasa a ser el primero
            primero = NuevoNodo
            cont += 1
        Else
            'Como ya habian elementos en la lista entonces el nuevo dato 
            'Se agrega despues del ultimo (imaginar graficamente que la cola 
            'se llena de derecha/ultimo a izquierda/primero)
            ultimo.pSiguiente = NuevoNodo
            cont += 1
        End If
        'Para ambos casos del if, el ultimo siempre tiene que apuntar al nuevo nodo
        ultimo = NuevoNodo
    End Sub

    Public Function obtener()
        'Si el ultimo no apunta a nada (lista vacia), se retorna null
        If primero Is Nothing Then
            Return Nothing
        Else
            'Como se trata de una cola (FIRST-IN, FIRST-OUT) el primero
            'en entrar siempre va a ser el primero en salir
            Return primero.dato
        End If
    End Function

    Public Sub eliminar_cola()
        'Al ser una cola se elimina siempre el primer dato que se ingreso

        'Se verifica que la lista no este vacia 
        If primero IsNot Nothing Then
            'Simplemente se hace que el puntero primero, apunte al nodo
            'que se encuentra despues del que esta actualmente como primero
            'el nodo que saldria se tendria que hacer null, pero como es visual
            'esto se hace de forma automatica
            primero = primero.pSiguiente
            cont -= 1

            If primero Is Nothing Then
                ultimo = Nothing
            End If
        End If
    End Sub

    Public Sub Actualizacion_instantanea_cola()
        aux = primero
        lb_datos.Items.Clear()

        If ((aux.pSiguiente Is Nothing) And (primero IsNot Nothing)) Then
            lb_datos.Items.Add(aux.dato)
        Else
            lb_datos.Items.Add(aux.dato)
            Do While (aux.pSiguiente IsNot Nothing)
                lb_datos.Items.Add(aux.pSiguiente.dato)
                aux = aux.pSiguiente
            Loop
        End If
    End Sub

    Public Sub Actualizar()
        If rb_cola.Checked Then
            aux = primero

            lb_datos.Items.Clear()
            lb_datos.Items.Add(aux.dato)
            Do While (aux.pSiguiente IsNot Nothing)
                lb_datos.Items.Add(aux.pSiguiente.dato)
                aux = aux.pSiguiente
            Loop

        ElseIf rb_pila.Checked Then
            aux = cabeza

            lb_datos.Items.Clear()
            lb_datos.Items.Add(aux.dato)
            Do While (aux.pSiguiente IsNot Nothing)
                lb_datos.Items.Add(aux.pSiguiente.dato)
                aux = aux.pSiguiente
            Loop
        End If

    End Sub

    Private Sub btn_agregar_Click(sender As Object, e As EventArgs) Handles btn_agregar.Click
        If rb_cola.Checked Then
            encolar(Val(tbox_ingresar.Text))
            Actualizacion_instantanea_cola()

        ElseIf rb_pila.Checked Then
            apilar(Val(tbox_ingresar.Text))
            Actualizacion_Instantanea_Pila()
        End If

        tbox_ingresar.Clear()
        tbox_ingresar.Focus()

        gb_operaciones.Enabled = True
        gb_eliminar.Enabled = True

    End Sub

    Private Sub cbox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbox1.SelectedIndexChanged
        If cbox1.SelectedIndex = 0 Then
            label_titulo.Visible = True
            resultado.Visible = True
            label_titulo.Text = "Mayor Elemento"
            resultado.Text = Mayor_Menor_Elemento(True, False)

        ElseIf cbox1.SelectedIndex = 1 Then
            label_titulo.Visible = True
            resultado.Visible = True
            label_titulo.Text = "Promedio de Elementos"
            resultado.Text = Promedio()

        ElseIf cbox1.SelectedIndex = 2 Then
            cbox2.Visible = True

        End If
    End Sub

    Public Function Mayor_Menor_Elemento(ByVal mayor As Boolean, ByVal menor As Boolean)
        Dim aux2 As Integer

        If rb_cola.Checked Then
            aux = primero
        ElseIf rb_pila.Checked Then
            aux = cabeza
            cont = cont2
        End If

        aux2 = aux.pSiguiente.dato

        If mayor Then
            For i As Integer = 0 To cont - 1 Step 1
                If aux2 < aux.dato Then
                    aux2 = aux.dato
                End If
                aux = aux.pSiguiente
            Next
        End If

        If menor Then
            For i As Integer = 0 To cont - 1 Step 1
                If aux2 > aux.dato Then
                    aux2 = aux.dato
                End If
                aux = aux.pSiguiente
            Next
        End If

        Return aux2
    End Function

    Public Function Promedio()
        Dim prom As Double

        If rb_cola.Checked Then
            aux = primero
        ElseIf rb_pila.Checked Then
            aux = cabeza
            cont = cont2
        End If

        For i As Integer = 0 To cont - 1 Step 1
            prom += aux.dato
            aux = aux.pSiguiente
        Next
        prom = prom / cont

        Return prom
    End Function

    Private Sub cbox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbox2.SelectedIndexChanged
        If cbox2.SelectedIndex = 0 Then
            OrdenarMayoraMenor()
        ElseIf cbox2.SelectedIndex = 1 Then
            OrdenarMenoraMayor()
        End If
    End Sub

    Public Sub OrdenarMayoraMenor()
        Dim valor As Integer
        Dim ordenado As Boolean = True
        Dim mayor As Integer = Mayor_Menor_Elemento(True, False)

        If rb_cola.Checked Then
            aux = primero

            Do While (ordenado)
                If (aux.dato < aux.pSiguiente.dato) Then
                    valor = aux.dato
                    aux.dato = aux.pSiguiente.dato
                    aux.pSiguiente.dato = valor

                    aux = aux.pSiguiente
                Else
                    aux = primero
                    ordenado = True
                End If

                If (aux.pSiguiente Is Nothing) Then
                    aux = primero
                    ordenado = True
                End If

                If (primero.dato = mayor) Then
                    ordenado = False
                End If
            Loop

        ElseIf rb_pila.Checked Then
            aux = cabeza

            Do While (ordenado)
                If (aux.dato < aux.pSiguiente.dato) Then
                    valor = aux.dato
                    aux.dato = aux.pSiguiente.dato
                    aux.pSiguiente.dato = valor

                    aux = aux.pSiguiente
                Else
                    aux = cabeza
                    ordenado = True
                End If

                If (aux.pSiguiente Is Nothing) Then
                    aux = cabeza
                    ordenado = True
                End If

                If (cabeza.dato = mayor) Then
                    ordenado = False
                End If
            Loop
        End If
        Actualizar()
    End Sub

    Public Sub OrdenarMenoraMayor()
        Dim valor As Integer
        Dim ordenado As Boolean = True
        Dim menor As Integer = Mayor_Menor_Elemento(False, True)

        If rb_cola.Checked Then
            aux = primero

            Do While (ordenado)
                If (aux.dato > aux.pSiguiente.dato) Then
                    valor = aux.dato
                    aux.dato = aux.pSiguiente.dato
                    aux.pSiguiente.dato = valor

                    aux = aux.pSiguiente
                Else
                    aux = primero
                    ordenado = True
                End If

                If (aux.pSiguiente Is Nothing) Then
                    aux = primero
                    ordenado = True
                End If

                If (primero.dato = menor) Then
                    ordenado = False
                End If
            Loop
        ElseIf rb_pila.Checked Then
            aux = cabeza

            Do While (ordenado)
                If (aux.dato > aux.pSiguiente.dato) Then
                    valor = aux.dato
                    aux.dato = aux.pSiguiente.dato
                    aux.pSiguiente.dato = valor

                    aux = aux.pSiguiente
                Else
                    aux = cabeza
                    ordenado = True
                End If

                If (aux.pSiguiente Is Nothing) Then
                    aux = cabeza
                    ordenado = True
                End If

                If (cabeza.dato = menor) Then
                    ordenado = False
                End If
            Loop
        End If
        Actualizar()
    End Sub

    Private Sub btn_eliminar_Click(sender As Object, e As EventArgs) Handles btn_eliminar.Click
        Dim valor As Integer
        Dim encontrado As Boolean = False

        If rb_cola.Checked Then
            aux = primero

            While (encontrado <> True)
                If aux.dato = Val(tbox_eliminar.Text) Then
                    valor = primero.dato
                    primero.dato = aux.dato
                    aux.dato = valor
                    encontrado = True
                    eliminar_cola()
                    Actualizar()
                ElseIf Val(tbox_eliminar.Text) = aux.pSiguiente.dato Then
                    valor = primero.dato
                    primero.dato = aux.pSiguiente.dato
                    aux.pSiguiente.dato = valor
                    encontrado = True
                    eliminar_cola()
                    Actualizar()
                End If

                If (aux.pSiguiente Is Nothing) And (encontrado <> True) Then
                    MsgBox("El numero no se encuentra en la lista")
                    encontrado = True
                End If

                aux = aux.pSiguiente
            End While

        ElseIf rb_pila.Checked Then
            aux = cabeza

            While (encontrado <> True)
                If aux.dato = Val(tbox_eliminar.Text) Then
                    valor = cabeza.dato
                    cabeza.dato = aux.dato
                    aux.dato = valor
                    encontrado = True
                    desapilar()
                    Actualizar()
                ElseIf Val(tbox_eliminar.Text) = aux.pSiguiente.dato Then
                    valor = cabeza.dato
                    cabeza.dato = aux.pSiguiente.dato
                    aux.pSiguiente.dato = valor
                    encontrado = True
                    desapilar()
                    Actualizar()
                End If

                If (aux.pSiguiente Is Nothing) And (encontrado <> True) Then
                    MsgBox("El numero no se encuentra en la lista")
                    encontrado = True
                End If

                aux = aux.pSiguiente
            End While
        End If

    End Sub

    Private cabeza As NodoProceso, eliminar As NodoProceso

    Private Sub rb_cola_CheckedChanged(sender As Object, e As EventArgs) Handles rb_cola.CheckedChanged
        gb_agregar.Enabled = True
    End Sub

    Private Sub rb_pila_CheckedChanged(sender As Object, e As EventArgs) Handles rb_pila.CheckedChanged
        gb_agregar.Enabled = True
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rb_cola.Checked = False
        rb_pila.Checked = False
    End Sub

    Public Sub apilar(elemento As Integer)
        Dim NuevoNodo As New NodoProceso(elemento)

        'La cabeza se toma como ultimo elemento
        NuevoNodo.pSiguiente = cabeza
        cabeza = NuevoNodo
        cont2 += 1
    End Sub

    Public Sub desapilar()
        If cabeza Is Nothing Then
            MsgBox("No se puede eliminar porque la lista esta vacia")
        Else
            eliminar = cabeza
            cabeza = cabeza.pSiguiente
            eliminar = Nothing
        End If
    End Sub

    Public Sub Actualizacion_Instantanea_Pila()
        aux = cabeza

        lb_datos.Items.Clear()
        lb_datos.Items.Add(aux.dato)

        While (aux.pSiguiente IsNot Nothing)
            lb_datos.Items.Add(aux.pSiguiente.dato)

            aux = aux.pSiguiente
        End While
    End Sub
End Class
