﻿Public Class Form1
    Private tam As Integer = 5
    Private cola(tam) As Double
    Private ocupado As Integer, primero As Integer

    Public Sub encolar(ByVal dato As Double)
        If ocupado = tam Then
            MsgBox("Cola llena")
        Else
            Dim lugar As Integer = (primero + ocupado) Mod tam
            cola(lugar) = dato
            ocupado += 1
        End If
    End Sub

    Public Sub desencolar()
        cola(primero) = 0
        primero = (primero + 1) Mod tam
        ocupado -= 1
    End Sub

    Public Sub muestracola()
        Dim i As Integer = 0

        lb_cola.Items.Clear()
        While i <> tam
            lb_cola.Items.Add(cola(i))
            i += 1
        End While
    End Sub

    Private Sub btn_ingresar_Click(sender As Object, e As EventArgs) Handles btn_ingresar.Click
        encolar(Val(tbox_ingresar.Text))

        If ocupado = tam Then
            tbox_ingresar.Enabled = False
            btn_ingresar.Enabled = False
            muestracola()
        End If

        tbox_ingresar.Clear()
        tbox_ingresar.Focus()
    End Sub

    Private Sub btn_buscar_Click(sender As Object, e As EventArgs) Handles btn_buscar.Click
        Dim encontrado As Boolean = False
        Dim i As Integer

        For j = 0 To tam
            If tbox_buscar.Text = cola(j) Then
                encontrado = True
                i = j
            End If
        Next

        If encontrado = True Then
            MsgBox("Posicion: " & i)
        Else
            MsgBox("El dato no se encuentra en la cola")
        End If
    End Sub

    Private Sub btn_eliminar_Click(sender As Object, e As EventArgs) Handles btn_eliminar.Click
        desencolar()
        muestracola()

        tbox_ingresar.Enabled = True
        btn_ingresar.Enabled = True
    End Sub

    Private Sub btn_valor_Click(sender As Object, e As EventArgs) Handles btn_valor.Click
        depurar(tbox_valor.Text)
    End Sub

    Public Sub depurar(ByVal valor As Double)
        For i As Integer = 0 To tam
            If tbox_valor.Text >= cola(i) Then
                cola(i) = 0
                primero = cola(i + 1)
            End If
        Next
        muestracola()
    End Sub
End Class
