﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbox_ingresar = New System.Windows.Forms.TextBox()
        Me.tbox_valor = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btn_ingresar = New System.Windows.Forms.Button()
        Me.lb_cola = New System.Windows.Forms.ListBox()
        Me.btn_valor = New System.Windows.Forms.Button()
        Me.btn_eliminar = New System.Windows.Forms.Button()
        Me.btn_buscar = New System.Windows.Forms.Button()
        Me.tbox_buscar = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(65, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Ingregar Dato"
        '
        'tbox_ingresar
        '
        Me.tbox_ingresar.Location = New System.Drawing.Point(155, 33)
        Me.tbox_ingresar.Name = "tbox_ingresar"
        Me.tbox_ingresar.Size = New System.Drawing.Size(215, 20)
        Me.tbox_ingresar.TabIndex = 1
        '
        'tbox_valor
        '
        Me.tbox_valor.Location = New System.Drawing.Point(206, 73)
        Me.tbox_valor.Name = "tbox_valor"
        Me.tbox_valor.Size = New System.Drawing.Size(164, 20)
        Me.tbox_valor.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(65, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Eliminar datos inferiores a:"
        '
        'btn_ingresar
        '
        Me.btn_ingresar.Location = New System.Drawing.Point(388, 33)
        Me.btn_ingresar.Name = "btn_ingresar"
        Me.btn_ingresar.Size = New System.Drawing.Size(85, 23)
        Me.btn_ingresar.TabIndex = 4
        Me.btn_ingresar.Text = "Ingresar"
        Me.btn_ingresar.UseVisualStyleBackColor = True
        '
        'lb_cola
        '
        Me.lb_cola.FormattingEnabled = True
        Me.lb_cola.Location = New System.Drawing.Point(68, 167)
        Me.lb_cola.Name = "lb_cola"
        Me.lb_cola.Size = New System.Drawing.Size(302, 290)
        Me.lb_cola.TabIndex = 5
        '
        'btn_valor
        '
        Me.btn_valor.Location = New System.Drawing.Point(388, 71)
        Me.btn_valor.Name = "btn_valor"
        Me.btn_valor.Size = New System.Drawing.Size(85, 23)
        Me.btn_valor.TabIndex = 6
        Me.btn_valor.Text = "Ingresar"
        Me.btn_valor.UseVisualStyleBackColor = True
        '
        'btn_eliminar
        '
        Me.btn_eliminar.Location = New System.Drawing.Point(388, 167)
        Me.btn_eliminar.Name = "btn_eliminar"
        Me.btn_eliminar.Size = New System.Drawing.Size(85, 23)
        Me.btn_eliminar.TabIndex = 7
        Me.btn_eliminar.Text = "Eliminar"
        Me.btn_eliminar.UseVisualStyleBackColor = True
        '
        'btn_buscar
        '
        Me.btn_buscar.Location = New System.Drawing.Point(388, 111)
        Me.btn_buscar.Name = "btn_buscar"
        Me.btn_buscar.Size = New System.Drawing.Size(85, 23)
        Me.btn_buscar.TabIndex = 10
        Me.btn_buscar.Text = "Buscar"
        Me.btn_buscar.UseVisualStyleBackColor = True
        '
        'tbox_buscar
        '
        Me.tbox_buscar.Location = New System.Drawing.Point(229, 113)
        Me.tbox_buscar.Name = "tbox_buscar"
        Me.tbox_buscar.Size = New System.Drawing.Size(141, 20)
        Me.tbox_buscar.TabIndex = 9
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(65, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(158, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Buscar posicion de un elemento"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(644, 506)
        Me.Controls.Add(Me.btn_buscar)
        Me.Controls.Add(Me.tbox_buscar)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btn_eliminar)
        Me.Controls.Add(Me.btn_valor)
        Me.Controls.Add(Me.lb_cola)
        Me.Controls.Add(Me.btn_ingresar)
        Me.Controls.Add(Me.tbox_valor)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tbox_ingresar)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Ejercicio 5"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents tbox_ingresar As TextBox
    Friend WithEvents tbox_valor As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btn_ingresar As Button
    Friend WithEvents lb_cola As ListBox
    Friend WithEvents btn_valor As Button
    Friend WithEvents btn_eliminar As Button
    Friend WithEvents btn_buscar As Button
    Friend WithEvents tbox_buscar As TextBox
    Friend WithEvents Label3 As Label
End Class
