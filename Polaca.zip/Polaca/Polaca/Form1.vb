﻿Public Class Form1
    Dim cont As Integer, cont2 As Integer
    Dim str_infijo As String, str_postfijo As String

    Private Class NodoProceso
        Public dato As String 'Se crea "puntero" a char
        Public pSiguiente As NodoProceso 'Se crea "puntero" a siguiente

        'Se crea un constructor
        Public Sub New(dato As String)
            Me.dato = dato
        End Sub
    End Class

    Private cabeza As NodoProceso, eliminar As NodoProceso, aux As NodoProceso

    Private Sub btn_ingresar_Click(sender As Object, e As EventArgs) Handles btn_ingresar.Click
        str_infijo = tbox_infija.Text
        tbox_postfijo.Text = postfijo(str_infijo)
    End Sub

    Public Sub apilar(elemento As String)
        Dim NuevoNodo As New NodoProceso(elemento)

        'La cabeza se toma como ultimo elemento
        NuevoNodo.pSiguiente = cabeza
        cabeza = NuevoNodo
        cont2 += 1
    End Sub

    Public Sub desapilar()
        If cabeza Is Nothing Then
            MsgBox("No se puede eliminar porque la lista esta vacia")
        Else
            eliminar = cabeza
            cabeza = cabeza.pSiguiente
            eliminar = Nothing
        End If
    End Sub

    Public Function Operador(ByVal str As String) As Boolean
        Select Case str
            Case "+" : Return True
            Case "-" : Return True
            Case "*" : Return True
            Case "/" : Return True
            Case "(" : Return True
            Case ")" : Return True
            Case "^" : Return True
            Case Else : Return False
        End Select
    End Function

    Public Function Orden(ByVal str As String) As Integer
        Select Case str
            Case "+" : Return 1
            Case "-" : Return 1
            Case "*" : Return 2
            Case "/" : Return 2
            Case "^" : Return 3
            Case Else : Return 0
        End Select
    End Function

    Public Function Mayor(ByVal a As String, ByVal b As String) As Boolean
        If Orden(a) >= Orden(b) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function postfijo(ByVal infijo As String)
        Dim str_postfijo As String
        aux = cabeza

        For i As Integer = 1 To infijo.Length() Step 1
            If IsNumeric(Mid(infijo, i, 1)) Then
                str_postfijo = str_postfijo & Mid(infijo, i, 1)

            ElseIf Operador(Mid(infijo, i, 1)) Then
                'Si esta vacia
                If aux Is Nothing Then
                    apilar(Mid(infijo, i, 1))

                Else
                    If Mid(infijo, i, 1) = "(" Then
                        apilar(Mid(infijo, i, 1))

                    ElseIf Mid(infijo, i, 1) = ")" Then
                        While aux.dato <> "("
                            str_postfijo = aux.dato
                            desapilar()

                        End While

                    Else
                        While (Mayor(aux.dato, Mid(infijo, i, 1)))
                            str_postfijo = str_postfijo & aux.dato
                            desapilar()

                        End While

                        If (Mayor(aux.dato, Mid(infijo, i, 1))) <> True Then
                            aux.dato = Mid(infijo, i, 1)
                        End If
                    End If
                End If
            End If
        Next

        While cabeza IsNot Nothing
            str_postfijo = str_postfijo & cabeza.dato
            desapilar()

        End While

        Return str_postfijo
    End Function

    Public Sub imprimir()
        While aux IsNot Nothing
            str_postfijo = str_postfijo & aux.dato
            desapilar()
        End While
    End Sub

End Class
