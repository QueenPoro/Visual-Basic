﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbox_infija = New System.Windows.Forms.TextBox()
        Me.btn_ingresar = New System.Windows.Forms.Button()
        Me.tbox_postfijo = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(68, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Infija"
        '
        'tbox_infija
        '
        Me.tbox_infija.Location = New System.Drawing.Point(121, 72)
        Me.tbox_infija.Name = "tbox_infija"
        Me.tbox_infija.Size = New System.Drawing.Size(188, 20)
        Me.tbox_infija.TabIndex = 1
        '
        'btn_ingresar
        '
        Me.btn_ingresar.Location = New System.Drawing.Point(121, 98)
        Me.btn_ingresar.Name = "btn_ingresar"
        Me.btn_ingresar.Size = New System.Drawing.Size(125, 23)
        Me.btn_ingresar.TabIndex = 2
        Me.btn_ingresar.Text = "Ingresar"
        Me.btn_ingresar.UseVisualStyleBackColor = True
        '
        'tbox_postfijo
        '
        Me.tbox_postfijo.Location = New System.Drawing.Point(121, 158)
        Me.tbox_postfijo.Name = "tbox_postfijo"
        Me.tbox_postfijo.Size = New System.Drawing.Size(188, 20)
        Me.tbox_postfijo.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(68, 161)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Postfijo"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(585, 396)
        Me.Controls.Add(Me.tbox_postfijo)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btn_ingresar)
        Me.Controls.Add(Me.tbox_infija)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents tbox_infija As TextBox
    Friend WithEvents btn_ingresar As Button
    Friend WithEvents tbox_postfijo As TextBox
    Friend WithEvents Label2 As Label
End Class
